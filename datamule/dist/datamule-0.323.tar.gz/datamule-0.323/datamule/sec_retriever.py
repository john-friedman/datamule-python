# File to fetch data quickly

# use whatever package is fastest for fetch

# import requests

# session = requests.Session()
# session.keep_alive = False

# response = session.get('https://example.com')