headers = {
    "User-Agent": "JoeShmoe joeshmoe@gmail.com"  # Replace with your information
}