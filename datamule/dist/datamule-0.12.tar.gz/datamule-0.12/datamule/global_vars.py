headers = {
    "User-Agent": "YourName YourEmail@example.com"  # Replace with your information
}