headers = {
    "User-Agent": "JoeShmoe joeshmoe@gmail.com"  # Replace with your information
}

indices_metadata_url = "https://www.dropbox.com/scl/fi/6jx6hkj4ff1is5uwpsheh/metadata.json?rlkey=672l2xgwd1jr0jq91voirmdu5&st=emrpydnh&dl=0"
indices_company_tickers_url = "https://www.dropbox.com/scl/fi/2ul35qmld3br3f9213guh/company_tickers.csv?rlkey=2wmz35xrcin1casyixscrmrag&st=ig2dpsi4&dl=0"
indices_submissions_url = "https://www.dropbox.com/scl/fi/jkh2eu8y0dijbbbr72owa/submissions_index.csv?rlkey=ll6jh7r6w4ues7ri54fwzhw9v&st=t7q8aj0g&dl=0"

dataset_10k_url = "https://www.dropbox.com/scl/fi/b5hex8bj21tij91pg7iwe/10K-JSON.zip?rlkey=l4fbefm71m1rdyz0hv69dsjel&st=rhpx6q0t&dl=0"
dataset_mda_url = "https://www.dropbox.com/scl/fi/w6rs3hh6xzyb3se6hkvav/mda_2024.zip?rlkey=srf0r2q19n2e7u40auygyl5lt&st=m64ripqq&dl=0"
