headers = {
    "User-Agent": "JoeShmoe joeshmoe@gmail.com"  # Replace with your information
}

dataset_10k_url = "https://www.dropbox.com/scl/fi/b5hex8bj21tij91pg7iwe/10K-JSON.zip?rlkey=l4fbefm71m1rdyz0hv69dsjel&st=rhpx6q0t&dl=0"
dataset_mda_url = "https://www.dropbox.com/scl/fi/w6rs3hh6xzyb3se6hkvav/mda_2024.zip?rlkey=srf0r2q19n2e7u40auygyl5lt&st=m64ripqq&dl=0"
dataset_xbrl_url = "https://www.dropbox.com/scl/fi/vpvd938phpie7yqjm11r2/company_concepts.zip?rlkey=1fpopy06hm2m1gzjqdrcuaves&st=buiogb7z&dl=0"
